#!/usr/bin/env python3

import json
from pathlib import Path
import sys

try:
    from jsonschema import Draft202012Validator
except ImportError:
    print("Missing dependency: jsonschema. Install with: pip install jsonschema", file=sys.stderr)
    sys.exit(1)

CATALOG_PATH = Path("docs/research/research.json")
SCHEMA_PATH = Path("docs/research/research.schema.json")

def main():
    if not CATALOG_PATH.exists():
        print(f"Missing catalog: {CATALOG_PATH}", file=sys.stderr)
        sys.exit(1)

    if not SCHEMA_PATH.exists():
        print(f"Missing schema: {SCHEMA_PATH}", file=sys.stderr)
        sys.exit(1)

    catalog = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(catalog), key=lambda e: list(e.path))

    if errors:
        print("Validation failed:")
        for error in errors:
            path = ".".join(str(p) for p in error.path) or "<root>"
            print(f"- {path}: {error.message}")
        sys.exit(1)

    print("Validation passed.")

if __name__ == "__main__":
    main()
